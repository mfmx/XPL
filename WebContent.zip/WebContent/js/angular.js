var app = angular.module('myApp', []);
app.controller('validateCtrl', ["$scope",function($scope, $routeParams, $location) {
    
    $scope.name="";
    $scope.email = '';
    $scope.pwd = '';
    
    
    $scope.go= function(){
window.location = 'loggedin.html';

    };
    console.log($scope.go);
    }
    ]);


app.controller("aboutUsController",["$scope", function($scope){
                             
$scope.prods=[{name:"customer service quality", img:"images/slider-img1.png", likes:0, dislikes:0},
{name:"Parking lot Service quality",img:"images/20130828_the-parking-lot-community-group_banner_img-2.jpg", likes:0, dislikes:0}];

 
$scope.plusOne = function(index) {         
  	$scope.prods[index].likes+=1};
               
$scope.minusOne=function(index){
	$scope.prods[index].dislikes+=1};
}
	                                    
 ]);



//
//
//
//
//var app = angular.module('myApp', []);
//
//app.service('sharedProperties', function() {
//    var stringValue = 'test string value';
//    var objectValue = {
//        data: 'test object value'
//    };
//    
//    return {
//        getString: function() {
//            return stringValue;
//        },
//        name: function(value) {
//            stringValue = value;
//        },
//        getObject: function() {
//            return objectValue;
//        }
//    }
//});
//
//app.controller('myController1', function($scope, $timeout, sharedProperties) {
//    $scope.stringValue = sharedProperties.getString();
//    $scope.objectValue = sharedProperties.getObject().data;    
//});
//
//app.controller('validateCtrl', function($scope, sharedProperties) {
//    
//    $scope.name=""
//    $scope.email = '';
//  $scope.pwd = '';
//  
//    
//    $scope.stringValue = sharedProperties.getString;
//    $scope.objectValue = sharedProperties.getObject();
//    $scope.name = function(newname) {
//        $scope.objectValue.data = newname;
//        sharedProperties.name(newname);
//    };
//});



app.directive("appDetail", function(){
return{
restrict:"E",
scope:{
    detail: "=" },
    
templateUrl: 'js/directives/appDetail.html' 

 
}  ;
    
    
            
});
